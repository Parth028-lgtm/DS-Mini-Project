import os, threading, time
from contextlib import asynccontextmanager
from fastapi import Body, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from core import Node

NODE_ID = os.getenv("NODE_ID", "A").upper()
DB_PATH = os.getenv("DB_PATH", f"/data/ward_{NODE_ID}.db")
SELF_URL = os.getenv("SELF_URL", "http://localhost:8000")
PUBLIC_URL = os.getenv("PUBLIC_URL") or None
JOIN = os.getenv("JOIN", "0") == "1"
HB_INTERVAL = float(os.getenv("HB_INTERVAL", "2"))

PEERS = {}
for item in filter(None, os.getenv("PEERS", "").split(",")):
    k, v = item.split("=", 1)
    PEERS[k.strip().upper()] = v.strip()

os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
node = Node(NODE_ID, DB_PATH, PEERS, self_url=SELF_URL, public_url=PUBLIC_URL,
            hb_timeout=float(os.getenv("HB_TIMEOUT", "6")))


def background():
    if JOIN:
        for _ in range(30):
            if node.bootstrap_join():
                break
            time.sleep(2)
    time.sleep(2)
    while True:
        try:
            node.heartbeat_tick()
        except Exception as e:  # never let the loop die
            print("heartbeat error:", e)
        time.sleep(HB_INTERVAL)


@asynccontextmanager
async def lifespan(app):
    threading.Thread(target=background, daemon=True).start()
    yield


app = FastAPI(title=f"CivicRelay Ward {NODE_ID}", lifespan=lifespan)


@app.middleware("http")
async def guard(request, call_next):
    if request.method != "OPTIONS" and not node.guard(request.url.path, request.headers.get("x-ward")):
        return JSONResponse({"detail": "node unavailable"}, status_code=503)
    return await call_next(request)


app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


# ---- client API ----
@app.get("/api/status")
def status():
    return node.status()


@app.get("/api/complaints")
def list_complaints():
    return node.list_complaints()


@app.post("/api/complaints")
def create(body: dict = Body(...)):
    if not (body.get("description") or "").strip():
        raise HTTPException(400, "description required")
    return node.create(body.get("type") or "Pothole", body.get("location") or "Unknown",
                       body["description"].strip(), body.get("priority") or "Medium")


@app.put("/api/complaints/{cid}")
def update(cid: str, body: dict = Body(...)):
    r = node.update(cid, **{k: body.get(k) for k in ("type", "location", "description", "status", "priority")})
    if not r:
        raise HTTPException(404, "complaint not found on this ward")
    return r


@app.get("/api/conflicts")
def conflicts():
    return node.list_conflicts()


@app.post("/api/resolve")
def resolve(body: dict = Body(...)):
    r = node.resolve(int(body["conflict_id"]), body.get("choice", "local"))
    if not r:
        raise HTTPException(404, "conflict not found")
    return r


@app.post("/api/sync")
def sync():
    return node.sync()


@app.post("/api/demo/conflict")
def demo():
    try:
        return node.demo_conflict()
    except Exception as e:
        raise HTTPException(409, f"Demo needs all wards reachable: {e}")


@app.get("/api/activity")
def activity():
    return node.list_activity()


@app.get("/api/election-log")
def election_log():
    return node.list_elog()


# ---- node-to-node API ----
@app.post("/api/import")
def import_records(body: dict = Body(...)):
    return node.import_records(body.get("records", []))


@app.post("/api/heartbeat")
def heartbeat(body: dict = Body(...)):
    return node.on_heartbeat(body.get("from", "?"))


@app.post("/api/election")
def election(body: dict = Body(...)):
    return node.on_election(body.get("from", "?"))


@app.post("/api/coordinator")
def coordinator(body: dict = Body(...)):
    return node.on_coordinator(body["id"])


@app.post("/api/join")
def join(body: dict = Body(...)):
    return node.join(body["id"].upper(), body["url"], body.get("public"), body.get("forwarded", False))


# ---- admin / simulation API ----
@app.post("/api/admin/fail")
def fail():
    node.set_down(True)
    return {"down": True}


@app.post("/api/admin/recover")
def recover():
    node.set_down(False)
    return {"down": False}


@app.post("/api/admin/partition")
def partition(body: dict = Body(...)):
    node.set_blocked(body.get("blocked", []))
    return {"blocked": sorted(node.blocked)}


@app.post("/api/admin/election")
def trigger_election():
    node.spawn(lambda: node.start_election(force=True))
    return {"ok": True}


@app.post("/api/admin/settings")
def settings(body: dict = Body(...)):
    if "auto_sync" in body:
        node.auto_sync = bool(body["auto_sync"])
    return {"auto_sync": node.auto_sync}


@app.post("/api/admin/reset")
def reset():
    node.reset()
    return {"ok": True}


@app.get("/")
def index():
    return FileResponse("static/index.html")


app.mount("/static", StaticFiles(directory="static"), name="static")
