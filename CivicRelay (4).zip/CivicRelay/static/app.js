/* CivicRelay dashboard - talks directly to every ward node (CORS enabled). */
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const COLORS = {A:'#2563eb', B:'#16a34a', C:'#f59e0b', D:'#8b5cf6', E:'#ec4899', F:'#14b8a6'};
const wc = id => COLORS[id] || '#64748b';
const prio = id => id.charCodeAt(0) - 64;
const TYPES = ['Pothole', 'Streetlight', 'Water Leak', 'Garbage'];
const STATUSES = ['Open', 'In Progress', 'Resolved'];
const PRIOS = ['High', 'Medium', 'Low'];

const ICONS = {
  home:'<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
  file:'<path d="M14 3H6v18h12V7z"/><path d="M14 3v4h4"/><path d="M9 13h6M9 17h6"/>',
  map:'<path d="M9 4L3 6v14l6-2 6 2 6-2V4l-6 2z"/><path d="M9 4v14M15 6v14"/>',
  bank:'<path d="M3 10l9-6 9 6"/><path d="M5 10v8M10 10v8M14 10v8M19 10v8M3 20h18"/>',
  sync:'<path d="M20 8a8 8 0 0 0-14-2L4 8"/><path d="M4 4v4h4"/><path d="M4 16a8 8 0 0 0 14 2l2-2"/><path d="M20 20v-4h-4"/>',
  users:'<circle cx="9" cy="8" r="3"/><path d="M3 20c0-3 3-5 6-5s6 2 6 5"/><circle cx="17" cy="9" r="2.5"/><path d="M17 14c2.5 0 4 1.5 4 4"/>',
  gear:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>',
  bell:'<path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 21h4"/>',
  alert:'<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18v.5"/>',
  check:'<circle cx="12" cy="12" r="9"/><path d="M8 12l3 3 5-6"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  crown:'<path d="M3 8l4 4 5-7 5 7 4-4-2 11H5z"/>',
  eye:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  pencil:'<path d="M4 20l1-4L17 4l3 3L8 19z"/>',
  net:'<circle cx="12" cy="5" r="2.5"/><circle cx="5" cy="18" r="2.5"/><circle cx="19" cy="18" r="2.5"/><path d="M11 7l-5 9M13 7l5 9M8 18h8"/>',
  list:'<path d="M8 6h13M8 12h13M8 18h13M3 6h.5M3 12h.5M3 18h.5"/>',
};
const ic = n => `<svg class="ic" viewBox="0 0 24 24">${ICONS[n] || ''}</svg>`;

/* ---------- state ---------- */
const S = {
  urls: {A:'http://localhost:8001', B:'http://localhost:8002', C:'http://localhost:8003'},
  order: ['A', 'B', 'C'], wards: {}, route: 'dashboard', page: 1,
  f: {q:'', ward:'', type:'', status:''}, selConflict: 0, loaded: false,
};
const PAGES = [
  ['dashboard','Dashboard','home'], ['complaints','Complaints','file'], ['map','Map View','map'],
  ['wards','Wards','bank'], ['sync','Sync & Conflicts','sync'], ['election','Election Logs','users'], ['settings','Settings','gear']];

/* ---------- helpers ---------- */
function ago(ts) {
  if (!ts) return '-';
  const s = Math.max(0, (Date.now() - new Date(ts).getTime()) / 1000);
  if (s < 5) return 'just now'; if (s < 60) return Math.round(s) + ' sec ago';
  if (s < 3600) return Math.round(s / 60) + ' min ago'; if (s < 86400) return Math.round(s / 3600) + ' hr ago';
  return Math.round(s / 86400) + ' d ago';
}
const hms = ts => ts ? new Date(ts).toLocaleTimeString([], {hour12: false}) : '-';
const dt = ts => ts ? new Date(ts).toLocaleString([], {hour12: false, day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit'}) : '-';
const vcs = vc => '[' + S.order.map(k => (vc || {})[k] || 0).join(', ') + ']';
const chip = id => `<span class="wchip" style="background:${wc(id)}">${esc(id)}</span>`;
const sBadge = s => `<span class="badge ${s === 'Open' ? 'b-open' : s === 'In Progress' ? 'b-prog' : 'b-done'}">${esc(s)}</span>`;
const pBadge = p => `<span class="badge b-${String(p).toLowerCase()}">${esc(p)}</span>`;
function toast(m) { const t = $('toast'); t.textContent = m; t.classList.remove('hidden'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.add('hidden'), 3200); }
function showModal(h) { $('mbox').innerHTML = h; $('modal').classList.remove('hidden'); }
function closeModal() { $('modal').classList.add('hidden'); }

async function fj(url, method = 'GET', body, ms = 2500) {
  const ac = new AbortController(); const t = setTimeout(() => ac.abort(), ms);
  try {
    const r = await fetch(url, {method, signal: ac.signal, headers: {'Content-Type': 'application/json'}, body: body ? JSON.stringify(body) : undefined});
    if (!r.ok) throw new Error(r.status + ' ' + (await r.text()));
    return await r.json();
  } finally { clearTimeout(t); }
}
const call = (id, method, path, body, ms) => fj(S.urls[id] + path, method, body, ms);

/* ---------- polling + derived data ---------- */
async function pollWard(id) {
  const w = S.wards[id] || (S.wards[id] = {id, complaints: [], conflicts: [], activity: [], elog: []});
  try { w.status = await call(id, 'GET', '/api/status'); w.reachable = true; }
  catch (e) { w.status = null; w.reachable = false; return; }
  for (const [pid, p] of Object.entries(w.status.peers || {})) {
    if (!S.urls[pid]) S.urls[pid] = p.public;
    if (!S.order.includes(pid)) { S.order.push(pid); S.order.sort(); }
  }
  if (w.status.down) { w.complaints = []; w.conflicts = []; return; }
  const get = p => call(id, 'GET', p).catch(() => null);
  const [c, cf, a, e] = await Promise.all([get('/api/complaints'), get('/api/conflicts'), get('/api/activity'), get('/api/election-log')]);
  if (c) w.complaints = c; if (cf) w.conflicts = cf; if (a) w.activity = a; if (e) w.elog = e;
}
async function poll() {
  await Promise.all(S.order.slice().map(pollWard));
  S.loaded = true; update();
}
const wardList = () => S.order.map(id => S.wards[id]).filter(Boolean);
function wstate(w) {
  if (!w || !w.reachable || !w.status || w.status.down) return 'offline';
  return (w.status.blocked || []).length ? 'isolated' : 'online';
}
const online = () => wardList().filter(w => wstate(w) !== 'offline');
function coordinator() {
  const c = {}; online().forEach(w => { const k = w.status.coordinator; if (k) c[k] = (c[k] || 0) + 1; });
  const e = Object.entries(c).sort((a, b) => b[1] - a[1]); return e.length ? e[0][0] : null;
}
function merged() {
  const m = {};
  wardList().forEach(w => (w.complaints || []).forEach(r => {
    const e = m[r.id] || (m[r.id] = {best: r, reps: {}});
    e.reps[w.id] = r;
    if (r.lamport > e.best.lamport || (r.lamport === e.best.lamport && r.updated_at > e.best.updated_at)) e.best = r;
  }));
  const n = online().length;
  return Object.values(m).map(e => {
    const reps = Object.values(e.reps);
    const diverged = reps.length < n || reps.some(r => JSON.stringify(Object.entries(r.vclock).sort()) !== JSON.stringify(Object.entries(reps[0].vclock).sort()));
    return {...e.best, reps: e.reps, diverged};
  }).sort((a, b) => b.created_at.localeCompare(a.created_at) || b.id.localeCompare(a.id));
}
const allConflicts = () => wardList().flatMap(w => (w.conflicts || []).map(c => ({...c, ward: w.id})));
function mergedActivity(kinds) {
  return wardList().flatMap(w => (w.activity || []).map(a => ({...a, ward: a.ward || w.id})))
    .filter(a => !kinds || kinds.includes(a.kind)).sort((a, b) => b.ts.localeCompare(a.ts) || b.id - a.id);
}
const mergedElog = () => wardList().flatMap(w => (w.elog || []).map(e => ({...e, node: e.node || w.id}))).sort((a, b) => b.ts.localeCompare(a.ts) || b.id - a.id);

/* ---------- map (self-contained SVG, no tiles needed) ---------- */
const WPOS = [[95, 95], [215, 180], [305, 75], [110, 205], [335, 205], [200, 55]];
const wpos = id => WPOS[Math.max(0, S.order.indexOf(id)) % WPOS.length];
function hash(s) { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) | 0; return Math.abs(h); }
function pinPos(c) { const [x, y] = wpos(c.ward), h = hash(c.id); return [x + (h % 70) - 35, y + (Math.floor(h / 70) % 56) - 28]; }
const stCol = s => s === 'Open' ? '#dc2626' : s === 'In Progress' ? '#f59e0b' : '#16a34a';
function mapSvg(list, opt = {}) {
  let s = `<svg class="map" viewBox="0 0 400 260" preserveAspectRatio="xMidYMid slice">
  <rect width="400" height="260" fill="#e8eef5"/>
  <g fill="#d7e7d2"><rect x="20" y="20" width="60" height="40" rx="6"/><rect x="250" y="130" width="70" height="46" rx="6"/><rect x="150" y="215" width="80" height="35" rx="6"/></g>
  <path d="M-10 150 C80 120 140 190 230 140 S350 90 410 120" stroke="#b9d6ee" stroke-width="22" fill="none" stroke-linecap="round"/>
  <g stroke="#fff" stroke-width="7" fill="none" stroke-linecap="round"><path d="M0 60 H400"/><path d="M0 225 H400"/><path d="M150 0 V260"/><path d="M270 0 V260"/><path d="M0 20 L400 235" stroke-width="4"/></g>
  <g stroke="#fff" stroke-width="3" fill="none"><path d="M60 0 V260"/><path d="M340 0 V260"/><path d="M0 105 H400"/><path d="M0 190 H400"/></g>`;
  S.order.forEach(id => {
    const [x, y] = wpos(id); const st = wstate(S.wards[id]);
    const col = st === 'offline' ? '#dc2626' : st === 'isolated' ? '#f59e0b' : wc(id);
    s += `<circle cx="${x}" cy="${y}" r="${opt.big ? 52 : 44}" fill="${col}" fill-opacity=".10" stroke="${col}" stroke-opacity=".5" stroke-dasharray="4 3"/>`;
  });
  (list || []).forEach(c => {
    const [x, y] = pinPos(c); const col = stCol(c.status);
    s += `<g transform="translate(${x} ${y})" ${opt.click ? `onclick="openComplaint('${c.id}')" style="cursor:pointer"` : ''}><path d="M0 0C-7-9-7-17 0-17S7-9 0 0z" transform="translate(0 4)" fill="${col}" stroke="#fff" stroke-width="1.2"/><circle cy="-8" r="2.6" fill="#fff"/><title>${esc(c.id)} - ${esc(c.type)} @ ${esc(c.location)} (${esc(c.status)})</title></g>`;
  });
  S.order.forEach(id => {
    const [x, y] = wpos(id); const st = wstate(S.wards[id]); const col = st === 'offline' ? '#dc2626' : wc(id);
    s += `<g transform="translate(${x} ${y})"><rect x="-27" y="-11" width="54" height="22" rx="11" fill="#fff" stroke="${col}" stroke-width="1.6"/><circle cx="-15" cy="0" r="4.5" fill="${col}"/><text x="-7" y="4" font-size="10.5" font-weight="700" fill="#14213d" font-family="Segoe UI,Arial">Ward ${esc(id)}</text></g>`;
  });
  return s + '</svg>';
}
const mapLegend = () => `<div class="legend">${S.order.map(id => `<span><i class="tdot" style="background:${wc(id)}"></i>Ward ${id} (${wstate(S.wards[id])})</span>`).join('')}</div>`;

/* ---------- UI chrome ---------- */
function renderNav() {
  $('nav').innerHTML = PAGES.map(([k, l, i]) => `<a class="${S.route === k ? 'on' : ''}" onclick="go('${k}')">${ic(i)}<span>${l}</span></a>`).join('');
  $('logo').innerHTML = ic('bank'); $('bell').innerHTML = ic('bell') + '<i id="bn"></i>';
}
function go(r) { S.route = r; S.page = 1; location.hash = r; renderNav(); $('page').innerHTML = (VIEWS[r] || VIEWS.dashboard).shell(); update(); }
function chrome() {
  const on = online().length, tot = wardList().length, co = coordinator();
  $('sdot').className = 'dot ' + (!S.loaded ? '' : on === tot ? 'on' : on ? 'warn' : 'off');
  $('snet').textContent = !S.loaded ? 'Connecting...' : on === tot ? 'Online' : on ? `Partial (${tot - on} offline)` : 'Offline';
  $('scoord').textContent = co ? 'Coordinator: Ward ' + co : 'Coordinator: electing...';
  const n = allConflicts().length, b = $('bn'); if (b) { b.textContent = n; b.style.display = n ? '' : 'none'; }
}
function update() { chrome(); const v = VIEWS[S.route] || VIEWS.dashboard; if (S.loaded || true) v.update(); }
const set = (id, h) => { const e = $(id); if (e) e.innerHTML = h; };

/* ---------- shared fragments ---------- */
function statCards() {
  const m = merged(), n = s => m.filter(c => c.status === s).length;
  const card = (cls, icn, lbl, v) => `<div class="card stat"><div class="ico ${cls}">${ic(icn)}</div><div><small>${lbl}</small><b>${v}</b></div></div>`;
  return card('i-blue', 'bank', 'Total Complaints', m.length) + card('i-red', 'alert', 'Open', n('Open')) + card('i-amber', 'clock', 'In Progress', n('In Progress')) + card('i-green', 'check', 'Resolved', n('Resolved'));
}
function recentRows(list) {
  return list.map(c => `<tr class="click" onclick="openComplaint('${c.id}')"><td><span class="link">#${esc(c.id)}</span></td><td>${esc(c.type)}</td><td>${esc(c.location)}</td><td>${chip(c.ward)}</td><td>${sBadge(c.status)}</td><td class="muted">${ago(c.updated_at)}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">No complaints yet - create one from the Complaints page.</td></tr>';
}
function feedHtml(list, n) {
  return '<ul class="feed">' + (list.slice(0, n).map(a => `<li><span class="d" style="background:${wc(a.ward)}"></span><div><b>${esc(a.message)}</b><br><small>Ward ${esc(a.ward)}</small></div><span class="t">${ago(a.ts)}</span></li>`).join('') || '<li class="empty">No activity yet</li>') + '</ul>';
}
function stateBadge(s) { return s === 'online' ? '<span class="badge b-on">Online</span>' : s === 'isolated' ? '<span class="badge b-iso">Isolated</span>' : '<span class="badge b-off">Offline</span>'; }

/* ---------- views ---------- */
const VIEWS = {};

VIEWS.dashboard = {
  shell: () => `<h1>Dashboard</h1><p class="sub">Overview of all wards, complaints and system status</p>
  <div class="grid g4 mb" id="d-stats"></div>
  <div class="grid g-dash mb"><div class="card"><h3>Ward Status</h3><div id="d-wards"></div></div>
  <div class="card"><h3>Ward Map</h3><div id="d-map"></div></div>
  <div class="card"><div class="row sp"><h3>Recent Activity</h3><a class="link" onclick="go('sync')">View All</a></div><div id="d-act"></div></div></div>
  <div class="grid g2"><div class="card"><div class="row sp"><h3>Recent Complaints</h3><a class="link" onclick="go('complaints')">View All</a></div><table><thead><tr><th>ID</th><th>Type</th><th>Location</th><th>Ward</th><th>Status</th><th>Updated</th></tr></thead><tbody id="d-rec"></tbody></table></div>
  <div class="card"><h3>System Overview</h3><div class="grid g2" id="d-sys"></div></div></div>`,
  update() {
    set('d-stats', statCards());
    set('d-wards', '<table><thead><tr><th>Ward</th><th>Status</th><th>Last Sync</th><th>Complaints</th></tr></thead><tbody>' +
      wardList().map(w => `<tr><td>${chip(w.id)} Ward ${w.id}</td><td>${stateBadge(wstate(w))}</td><td class="muted">${w.status ? ago(w.status.last_sync) : '-'}</td><td>${wstate(w) === 'offline' ? '-' : w.status.complaints}</td></tr>`).join('') + '</tbody></table>');
    set('d-map', mapSvg(merged()) + mapLegend());
    set('d-act', feedHtml(mergedActivity(), 6));
    set('d-rec', recentRows(merged().slice(0, 5)));
    const off = wardList().filter(w => wstate(w) === 'offline'), co = coordinator();
    const syncs = wardList().map(w => w.status && w.status.last_sync).filter(Boolean).sort().pop();
    const inc = off.length + allConflicts().length;
    const tile = (cls, icn, ic2, l, v, s) => `<div class="tile ${cls}"><div class="ico ${ic2}">${ic(icn)}</div><div><small>${l}</small><b>${v}</b><small>${s}</small></div></div>`;
    set('d-sys',
      tile('t-red', 'net', 'i-red', 'Network Status', off.length ? `Partial (${off.length} offline)` : 'All wards online', off.length ? 'Ward ' + off.map(w => w.id).join(', ') + ' offline' : 'Cluster healthy') +
      tile('t-blue', 'crown', 'i-blue', 'Current Coordinator', co ? 'Ward ' + co : 'Electing...', 'Bully algorithm') +
      tile('t-green', 'sync', 'i-green', 'Last Synchronization', syncs ? ago(syncs) : 'Never', 'Auto-sync by coordinator') +
      tile('t-amber', 'alert', 'i-amber', 'Incidents', inc, `${allConflicts().length} open conflict(s), ${off.length} node(s) down`));
  }
};

VIEWS.complaints = {
  shell: () => `<h1>Complaints</h1><p class="sub">Manage and track municipal maintenance complaints across all wards.</p>
  <div class="grid g4 mb" id="c-stats"></div>
  <div class="grid g-comp"><div class="card"><h3>All Complaints</h3>
    <div class="filters"><input id="f-q" placeholder="Search by ID, location or description..." oninput="S.f.q=this.value;S.page=1;VIEWS.complaints.table()">
    <select id="f-w" onchange="S.f.ward=this.value;S.page=1;VIEWS.complaints.table()"></select>
    <select id="f-t" onchange="S.f.type=this.value;S.page=1;VIEWS.complaints.table()"><option value="">All Types</option>${TYPES.map(t => `<option>${t}</option>`).join('')}</select>
    <select id="f-s" onchange="S.f.status=this.value;S.page=1;VIEWS.complaints.table()"><option value="">All Status</option>${STATUSES.map(t => `<option>${t}</option>`).join('')}</select></div>
    <div id="c-table"></div></div>
  <div><div class="card mb"><h3>Create New Complaint</h3>
    <label>Complaint Type *</label><select id="n-type">${TYPES.map(t => `<option>${t}</option>`).join('')}</select>
    <label>Location *</label><input id="n-loc" placeholder="Enter location (e.g., Main Road, Sector 12)">
    <label>Description *</label><textarea id="n-desc" placeholder="Describe the issue in detail..."></textarea>
    <div class="grid g2"><div><label>Ward *</label><select id="n-ward"></select></div><div><label>Priority</label><select id="n-prio"><option>Medium</option><option>High</option><option>Low</option></select></div></div>
    <button class="btn" style="width:100%;margin-top:14px" onclick="createComplaint()">Submit Complaint</button></div>
  <div class="card"><h3>Location Map</h3><div id="c-map"></div></div></div></div>`,
  update() {
    set('c-stats', statCards());
    const wsel = $('f-w'); if (wsel && wsel.options.length !== S.order.length + 1) wsel.innerHTML = '<option value="">All Wards</option>' + S.order.map(i => `<option ${S.f.ward === i ? 'selected' : ''}>${i}</option>`).join('');
    const nw = $('n-ward'); if (nw && nw.options.length !== S.order.length) nw.innerHTML = S.order.map(i => `<option value="${i}">Ward ${i}</option>`).join('');
    this.table(); set('c-map', mapSvg(merged()) + mapLegend());
  },
  table() {
    const q = S.f.q.toLowerCase();
    const list = merged().filter(c => (!S.f.ward || c.ward === S.f.ward) && (!S.f.type || c.type === S.f.type) && (!S.f.status || c.status === S.f.status) &&
      (!q || (c.id + c.location + c.description + c.type).toLowerCase().includes(q)));
    const per = 8, pages = Math.max(1, Math.ceil(list.length / per)); if (S.page > pages) S.page = pages;
    const rows = list.slice((S.page - 1) * per, S.page * per);
    set('c-table', `<table><thead><tr><th>ID</th><th>Type</th><th>Location</th><th>Ward</th><th>Status</th><th>Priority</th><th>Created</th><th>Actions</th></tr></thead><tbody>` +
      (rows.map(c => `<tr><td><span class="link" onclick="openComplaint('${c.id}')">#${esc(c.id)}</span>${c.diverged ? ' <span class="badge b-iso" title="Replicas differ - synchronize">sync</span>' : ''}</td><td>${esc(c.type)}</td><td>${esc(c.location)}</td><td>${chip(c.ward)}</td><td>${sBadge(c.status)}</td><td>${pBadge(c.priority)}</td><td class="muted">${dt(c.created_at)}</td>
      <td><div class="act"><button onclick="openComplaint('${c.id}')" title="View">${ic('eye')}</button><button onclick="openComplaint('${c.id}',true)" title="Edit">${ic('pencil')}</button></div></td></tr>`).join('') || '<tr><td colspan="8" class="empty">No complaints match.</td></tr>') +
      `</tbody></table><div class="pager"><span>Showing ${list.length ? (S.page - 1) * per + 1 : 0} to ${Math.min(S.page * per, list.length)} of ${list.length} complaints</span><span>` +
      Array.from({length: pages}, (_, i) => `<button class="${i + 1 === S.page ? 'on' : ''}" onclick="S.page=${i + 1};VIEWS.complaints.table()">${i + 1}</button>`).join(' ') + '</span></div>');
  }
};

VIEWS.map = {
  shell: () => `<h1>Map View</h1><p class="sub">Complaint locations across ward service areas. Click a pin for details.</p>
  <div class="card"><div id="m-map"></div><div class="legend"><span><i class="tdot" style="background:#dc2626"></i>Open</span><span><i class="tdot" style="background:#f59e0b"></i>In Progress</span><span><i class="tdot" style="background:#16a34a"></i>Resolved</span></div><div id="m-leg"></div></div>`,
  update() { set('m-map', mapSvg(merged(), {big: true, click: true})); set('m-leg', mapLegend()); }
};

VIEWS.wards = {
  shell: () => `<h1>Wards</h1><p class="sub">Independent ward services - each with its own SQLite database. Simulate failures and network partitions here.</p>
  <div class="row mb"><button class="btn warn" onclick="healAll()">Heal All Partitions</button><button class="btn out" onclick="syncAll()">Synchronize All Wards</button></div>
  <div class="grid g3 mb" id="w-cards"></div>
  <div class="card"><h3>Scalability - add Ward D without touching A, B or C</h3>
  <p class="muted">New wards join through any running ward (the seed), which announces them to the whole cluster. Vector clocks and the election adapt automatically.</p>
  <div class="code">docker compose -f docker-compose.yml -f docker-compose.scale.yml up -d --build ward-d</div></div>`,
  update() {
    set('w-cards', wardList().map(w => {
      const st = wstate(w), s = w.status, co = coordinator() === w.id;
      return `<div class="card"><div class="wcard"><div class="big" style="background:${st === 'offline' ? '#94a3b8' : wc(w.id)}">${ic('bank')}</div><div class="grow"><div class="row sp"><h3 style="margin:0">Ward ${w.id}</h3>${stateBadge(st)}</div>
      <div class="muted">${co ? '<span class="badge b-blue">Coordinator</span> ' : ''}<a class="link" href="${esc(S.urls[w.id])}" target="_blank">${esc(S.urls[w.id])}</a></div></div></div>
      ${s ? `<div class="kv" style="margin:12px 0"><span>Priority</span><span>${s.priority}</span><span>Complaints</span><span>${st === 'offline' ? '-' : s.complaints}</span><span>Open conflicts</span><span>${st === 'offline' ? '-' : s.conflicts}</span><span>Vector clock</span><span class="vc">${vcs(s.vclock)}</span><span>Lamport clock</span><span>${s.lamport}</span><span>Uptime</span><span>${s.uptime}s</span></div>` : '<p class="empty">Container unreachable</p>'}
      <div class="row"><button class="btn sm ${s && s.down ? 'ok' : 'dan'}" onclick="${s && s.down ? 'recoverWard' : 'failWard'}('${w.id}')">${s && s.down ? 'Recover Node' : 'Simulate Failure'}</button>
      <button class="btn sm out" onclick="isolateWard('${w.id}')">Isolate (partition)</button></div></div>`;
    }).join(''));
  }
};

function vcCard(w) {
  const st = wstate(w), keys = S.order, v = (w.status && w.status.vclock) || {};
  return `<div class="card"><div class="row sp"><div class="row">${chip(w.id)}<b>Ward ${w.id}</b></div>${stateBadge(st)}</div><small class="muted">Vector Clock</small>
  <div class="vbox">${keys.map(k => `<div><b>${v[k] || 0}</b>${k}</div>`).join('')}</div></div>`;
}
function timelineSvg() {
  const ev = mergedActivity(['created', 'updated', 'resolved']).filter(a => a.vclock).slice(0, 14).reverse();
  if (!ev.length) return '<div class="empty">No events yet</div>';
  const W = 640, lane = 46, H = S.order.length * lane + 20, step = (W - 110) / Math.max(1, ev.length);
  let s = `<svg viewBox="0 0 ${W} ${H}" style="width:100%">`;
  S.order.forEach((id, i) => {
    const y = 28 + i * lane;
    s += `<circle cx="14" cy="${y}" r="5" fill="${wc(id)}"/><text x="26" y="${y + 4}" font-size="11" fill="#14213d" font-weight="600">Ward ${id}</text><line x1="90" y1="${y}" x2="${W - 10}" y2="${y}" stroke="${wc(id)}" stroke-opacity=".4" stroke-width="2"/>`;
  });
  ev.forEach((a, k) => {
    const i = S.order.indexOf(a.ward); if (i < 0) return;
    const x = 110 + k * step, y = 28 + i * lane;
    s += `<circle cx="${x}" cy="${y}" r="7" fill="${wc(a.ward)}" stroke="#fff" stroke-width="2"><title>${esc(a.message)} ${vcs(a.vclock)}</title></circle><text x="${x}" y="${y - 12}" font-size="8.5" text-anchor="middle" fill="#6b7a93">${esc(a.kind)}</text><text x="${x}" y="${y + 20}" font-size="8.5" text-anchor="middle" fill="#14213d">${vcs(a.vclock).replace(/ /g, '')}</text>`;
  });
  return s + '</svg>';
}
VIEWS.sync = {
  shell: () => `<h1>Vector Clocks &amp; Conflict Detection</h1><p class="sub">Track updates across wards and detect conflicts using vector clocks and Lamport clocks.</p>
  <div class="row mb"><button class="btn ok" onclick="syncAll()">Synchronize All Wards</button><button class="btn warn" onclick="runDemo()">Run Conflict Demonstration</button></div>
  <div class="grid g4 mb" id="s-vc"></div>
  <div class="grid g-sync mb"><div class="card"><h3>Complaint Updates</h3><div class="scroll"><table><thead><tr><th>Time</th><th>Ward</th><th>Complaint ID</th><th>Type</th><th>Action</th><th>Vector Clock</th><th>Lamport</th></tr></thead><tbody id="s-upd"></tbody></table></div></div>
  <div id="s-conf"></div></div>
  <div class="grid g-sync"><div class="card"><h3>${ic('list').replace('class="ic"', 'class="ic" style="vertical-align:-4px"')} Vector Clock Timeline</h3><div id="s-tl"></div></div>
  <div class="card"><h3>Recent Events</h3><div id="s-ev"></div></div></div>`,
  update() {
    const lam = Math.max(0, ...wardList().map(w => (w.status && w.status.lamport) || 0));
    set('s-vc', wardList().map(vcCard).join('') + `<div class="card"><div class="row"><div class="ico i-blue" style="width:34px;height:34px;border-radius:50%;display:grid;place-items:center">${ic('sync')}</div><div><small class="muted">Event Order</small><br><b>Lamport Clock: ${lam}</b></div></div><small class="muted">Last sync ${ago(wardList().map(w => w.status && w.status.last_sync).filter(Boolean).sort().pop())}</small></div>`);
    const types = Object.fromEntries(merged().map(c => [c.id, c.type]));
    const upd = mergedActivity(['created', 'updated', 'resolved']).slice(0, 25);
    set('s-upd', upd.map(a => `<tr><td class="muted">${hms(a.ts)}</td><td>${chip(a.ward)}</td><td><span class="link" onclick="openComplaint('${a.complaint_id}')">#${esc(a.complaint_id)}</span></td><td>${esc(types[a.complaint_id] || '-')}</td><td><span class="badge ${a.kind === 'created' ? 'b-on' : a.kind === 'resolved' ? 'b-blue' : 'b-prog'}">${esc(a.kind)}</span></td><td><span class="vc">${vcs(a.vclock)}</span></td><td>${a.lamport ?? ''}</td></tr>`).join('') || '<tr><td colspan="7" class="empty">No updates yet</td></tr>');
    const cf = allConflicts();
    if (S.selConflict >= cf.length) S.selConflict = 0;
    const c = cf[S.selConflict];
    set('s-conf', c ? `<div class="conf"><div class="row sp"><h3 style="color:#b42318;margin:0">${ic('alert').replace('class="ic"', 'class="ic" style="vertical-align:-4px"')} Conflict Detected</h3><span class="badge b-off">${cf.length} open</span></div>
      <p>Complaint <b>#${esc(c.complaint_id)}</b> (${esc((c.local || {}).type)}) was updated concurrently by <b>Ward ${esc((c.local || {}).last_updated_by)}</b> and <b>Ward ${esc(c.remote.last_updated_by)}</b>. Detected at Ward ${esc(c.ward)}.</p>
      <div class="pair"><div style="background:#e8f7ee"><small class="muted">Local (Ward ${esc(c.ward)}) vector clock</small><br><b class="vc">${vcs((c.local || {}).vclock)}</b></div><div style="background:#fff3de"><small class="muted">Remote (Ward ${esc(c.remote.last_updated_by)}) vector clock</small><br><b class="vc">${vcs(c.remote.vclock)}</b></div></div>
      <div class="row"><button class="btn sm" onclick="viewConflict(${S.selConflict})">View Details</button><button class="btn sm out" onclick="viewConflict(${S.selConflict})">Manual Resolve</button><button class="btn sm out" onclick="resolveConflict('${c.ward}',${c.id},'auto')">Auto Resolve</button>
      ${cf.length > 1 ? `<button class="btn sm out" onclick="S.selConflict=(S.selConflict+1)%${cf.length};VIEWS.sync.update()">Next conflict &rsaquo;</button>` : ''}</div></div>`
      : `<div class="card"><h3>${ic('check').replace('class="ic"', 'class="ic" style="vertical-align:-4px;color:#16a34a"')} No Conflicts</h3><p class="muted">All replicas are causally ordered. Use <b>Run Conflict Demonstration</b> to create two concurrent updates on different wards, then synchronize.</p></div>`);
    set('s-tl', timelineSvg());
    set('s-ev', feedHtml(mergedActivity(['created', 'updated', 'resolved', 'conflict', 'sync']), 7));
  }
};

function commGraph() {
  const ws = wardList(), n = ws.length, cx = 190, cy = 120, r = 85;
  const pos = {}; ws.forEach((w, i) => { const a = -Math.PI / 2 + i * 2 * Math.PI / n; pos[w.id] = [cx + r * Math.cos(a), cy + r * Math.sin(a)]; });
  const co = coordinator(); let s = '<svg viewBox="0 0 380 250" style="width:100%">';
  const linked = (a, b) => wstate(a) !== 'offline' && wstate(b) !== 'offline' && !(a.status.blocked || []).includes(b.id) && !(b.status.blocked || []).includes(a.id);
  ws.forEach((a, i) => ws.slice(i + 1).forEach(b => {
    const ok = linked(a, b), [x1, y1] = pos[a.id], [x2, y2] = pos[b.id];
    s += `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${ok ? '#16a34a' : '#dc2626'}" stroke-width="2" ${ok ? '' : 'stroke-dasharray="5 4"'}/>`;
    if (!ok) s += `<text x="${(x1 + x2) / 2}" y="${(y1 + y2) / 2}" fill="#dc2626" font-weight="700" text-anchor="middle">x</text>`;
  }));
  ws.forEach(w => {
    const [x, y] = pos[w.id], st = wstate(w);
    s += `<circle cx="${x}" cy="${y}" r="22" fill="${st === 'offline' ? '#94a3b8' : wc(w.id)}" stroke="#fff" stroke-width="3"/><text x="${x}" y="${y + 5}" text-anchor="middle" fill="#fff" font-weight="700" font-size="15">${w.id}</text>
    <text x="${x}" y="${y + 40}" text-anchor="middle" font-size="10.5" fill="${st === 'online' ? '#14213d' : '#dc2626'}">${co === w.id ? 'Coordinator' : st === 'online' ? 'Online' : st === 'isolated' ? 'Isolated' : 'Offline'}</text>${co === w.id ? `<text x="${x + 18}" y="${y - 18}" font-size="16">&#9733;</text>` : ''}`;
  });
  return s + '</svg>';
}
const EV = {'Failure Detected': ['Failed', 'b-off'], 'Node Failure': ['Failed', 'b-off'], 'Election Message': ['In Progress', 'b-blue'], 'Election Response': ['Responded', 'b-purple'], 'Priority Check': ['Responded', 'b-purple'], 'Coordinator Elected': ['Success', 'b-on'], 'Acknowledgement': ['Success', 'b-on'], 'Election Complete': ['Success', 'b-on'], 'Node Recovery': ['Success', 'b-on']};
VIEWS.election = {
  shell: () => `<h1>Leader Election</h1><p class="sub">Bully Algorithm - coordinator selection with heartbeat-based failure detection</p>
  <div class="row mb"><button class="btn dan" onclick="killCoordinator()">Simulate Coordinator Failure</button><button class="btn out" onclick="triggerElection()">Trigger Election</button><button class="btn ok" onclick="recoverAll()">Recover All Nodes</button></div>
  <div class="grid g-sync mb"><div class="card" id="e-steps"></div><div class="card" id="e-cur"></div></div>
  <div class="grid g-sync mb"><div class="card"><h3>Election Logs</h3><div class="scroll"><table><thead><tr><th>Time</th><th>Node</th><th>Event</th><th>Details</th></tr></thead><tbody id="e-log"></tbody></table></div></div>
  <div class="card"><h3>Election Process (Live)</h3><div id="e-live"></div></div></div>
  <div class="grid g-sync"><div class="card"><h3>Node Status</h3><div class="grid g3" id="e-nodes"></div></div><div class="card"><h3>Node Communication Graph</h3><div id="e-graph"></div><div class="legend"><span style="color:#16a34a">&#9473; Active connection</span><span style="color:#dc2626">&#9548; Disconnected</span></div></div></div>`,
  update() {
    const co = coordinator(), cw = co && S.wards[co], coOk = cw && wstate(cw) === 'online', log = mergedElog();
    const recent = log.some(e => ['Failure Detected', 'Node Failure', 'Election Message'].includes(e.event) && Date.now() - new Date(e.ts).getTime() < 90000);
    const st = !coOk ? [' bad', ' act', ''] : recent ? [' done', ' done', ' ok'] : ['', '', ' ok'];
    set('e-steps', `<div class="steps"><div class="step${st[0]}"><span class="n">1</span><div><b>Failure Detected</b><small>${!coOk ? 'Coordinator is unavailable' : 'Heartbeat timeout detects dead nodes'}</small></div></div><span class="arrow">&rarr;</span>
      <div class="step${st[1]}"><span class="n">2</span><div><b>Election In Progress</b><small>Nodes send election messages</small></div></div><span class="arrow">&rarr;</span>
      <div class="step${st[2]}"><span class="n">3</span><div><b>New Coordinator</b><small>${co ? 'Ward ' + co + ' is the coordinator' : 'Waiting for election'}</small></div></div></div>`);
    set('e-cur', `<div class="row"><div class="ico i-blue" style="width:44px;height:44px;border-radius:50%;display:grid;place-items:center">${ic('crown')}</div><div><small class="muted">Current Coordinator</small><br><b style="font-size:20px">${co ? 'Ward ' + co : 'Electing...'}</b> ${coOk ? '<span class="badge b-on">Active</span>' : ''}<br><small class="muted">Highest-priority live node wins (priority A=1 ... higher number = higher priority)</small></div></div>`);
    set('e-log', log.slice(0, 30).map(e => `<tr><td class="muted">${hms(e.ts)}</td><td>${chip(e.node)}</td><td>${esc(e.event)}</td><td>${esc(e.details)}</td></tr>`).join('') || '<tr><td colspan="4" class="empty">No election events yet</td></tr>');
    set('e-live', '<ul class="tl">' + log.slice(0, 6).reverse().map((e, i) => { const t = EV[e.event] || ['Info', 'b-gray']; return `<li><span class="n">${i + 1}</span><div><b>Ward ${esc(e.node)} - ${esc(e.event)}</b><br><small class="muted">${esc(e.details)} &middot; ${hms(e.ts)}</small></div><span class="badge ${t[1]}" style="margin-left:auto;height:fit-content">${t[0]}</span></li>`; }).join('') + '</ul>');
    set('e-nodes', wardList().map(w => {
      const s = w.status, seen = wardList().filter(o => o.id !== w.id && o.status && o.status.peers && o.status.peers[w.id] && o.status.peers[w.id].last_seen_ago != null).map(o => o.status.peers[w.id].last_seen_ago);
      return `<div class="card" style="padding:12px"><div class="row">${chip(w.id)}<b>Ward ${w.id}</b></div><div style="margin:6px 0">${stateBadge(wstate(w))}${co === w.id ? ' <span class="badge b-blue">Coordinator</span>' : ''}</div>
      <div class="kv"><span>Last heartbeat</span><span>${wstate(w) === 'offline' ? (seen.length ? Math.round(Math.min(...seen)) + 's ago' : '-') : 'now'}</span><span>Uptime</span><span>${s ? s.uptime + 's' : '-'}</span><span>Priority</span><span>${prio(w.id)}</span></div></div>`;
    }).join(''));
    set('e-graph', commGraph());
  }
};

VIEWS.settings = {
  shell: () => `<h1>Settings</h1><p class="sub">Cluster configuration and maintenance</p>
  <div class="grid g2"><div class="card"><h3>Cluster</h3><div id="st-info"></div></div>
  <div class="card"><h3>Behaviour</h3><label class="switch"><input type="checkbox" id="st-auto" onchange="setAuto(this.checked)"> Coordinator runs automatic synchronization (every 15 s)</label>
  <p class="muted">Heartbeat interval 2 s &middot; failure timeout 6 s &middot; election algorithm: Bully</p>
  <h3 style="margin-top:20px">Maintenance</h3><div class="row"><button class="btn warn" onclick="healAll()">Heal Network Partitions</button><button class="btn dan" onclick="resetAll()">Reset All Data</button></div></div></div>`,
  update() {
    set('st-info', '<table><thead><tr><th>Ward</th><th>URL</th><th>Priority</th><th>State</th></tr></thead><tbody>' + wardList().map(w => `<tr><td>${chip(w.id)} Ward ${w.id}</td><td>${esc(S.urls[w.id])}</td><td>${prio(w.id)}</td><td>${stateBadge(wstate(w))}</td></tr>`).join('') + '</tbody></table>');
    const a = $('st-auto'), w = online()[0]; if (a && w && document.activeElement !== a) a.checked = !!w.status.auto_sync;
  }
};

/* ---------- actions ---------- */
async function createComplaint() {
  const body = {type: $('n-type').value, location: $('n-loc').value.trim(), description: $('n-desc').value.trim(), priority: $('n-prio').value}, id = $('n-ward').value;
  if (!body.location || !body.description) return toast('Location and description are required');
  try { const c = await call(id, 'POST', '/api/complaints', body); toast(`Complaint #${c.id} created at Ward ${id} ${vcs(c.vclock)}`); $('n-loc').value = ''; $('n-desc').value = ''; poll(); }
  catch (e) { toast(`Ward ${id} unavailable: ${e.message}`); }
}
function openComplaint(id, edit) {
  const c = merged().find(x => x.id === id); if (!c) return;
  const reps = Object.entries(c.reps);
  showModal(`<div class="row sp"><h3 style="margin:0">Complaint #${esc(c.id)}</h3><button class="btn sm out" onclick="closeModal()">Close</button></div>
  <p><b>${esc(c.type)}</b> &middot; ${esc(c.location)} &middot; origin ${chip(c.ward)} ${sBadge(c.status)} ${pBadge(c.priority)}</p><p>${esc(c.description)}</p>
  <h3>Replicas</h3><table><thead><tr><th>Ward</th><th>Status</th><th>Vector clock</th><th>Lamport</th><th>Last updated by</th></tr></thead><tbody>${reps.map(([w, r]) => `<tr><td>${chip(w)}</td><td>${sBadge(r.status)}</td><td><span class="vc">${vcs(r.vclock)}</span></td><td>${r.lamport}</td><td>${esc(r.last_updated_by)}</td></tr>`).join('')}</tbody></table>
  <h3 style="margin-top:18px">Update this complaint</h3><div class="grid g2"><div><label>Perform update at ward</label><select id="u-ward">${reps.map(([w]) => `<option ${w === c.ward ? 'selected' : ''}>${w}</option>`).join('')}</select></div>
  <div><label>Status</label><select id="u-st">${STATUSES.map(s => `<option ${s === c.status ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
  <div><label>Priority</label><select id="u-pr">${PRIOS.map(s => `<option ${s === c.priority ? 'selected' : ''}>${s}</option>`).join('')}</select></div></div>
  <label>Description</label><textarea id="u-desc">${esc(c.description)}</textarea><button class="btn" style="margin-top:12px" onclick="saveEdit('${c.id}')">Save update</button>`);
  if (edit) setTimeout(() => $('u-desc') && $('u-desc').focus(), 50);
}
async function saveEdit(id) {
  const w = $('u-ward').value;
  try { const r = await call(w, 'PUT', '/api/complaints/' + id, {status: $('u-st').value, priority: $('u-pr').value, description: $('u-desc').value}); toast(`Updated at Ward ${w} ${vcs(r.vclock)}`); closeModal(); poll(); }
  catch (e) { toast('Update failed: ' + e.message); }
}
async function syncAll() {
  toast('Synchronizing all wards...'); let found = 0, errs = 0;
  for (let pass = 0; pass < 2; pass++) for (const w of online()) {
    try { const r = await call(w.id, 'POST', '/api/sync', null, 15000); found += r.conflicts.length; Object.values(r.peers).forEach(p => { if (p.error) errs++; }); } catch (e) { errs++; }
  }
  toast(`Sync complete - ${found} new conflict(s)` + (errs ? `, ${errs} unreachable link(s)` : '')); poll();
}
async function runDemo() {
  const w = online()[0]; if (!w) return toast('No ward online');
  try { const r = await call(w.id, 'POST', '/api/demo/conflict', null, 15000); toast(`Demo: #${r.complaint_id} updated independently on Wards ${r.updated_on.join(' & ')}. Now synchronize.`); poll(); }
  catch (e) { toast('Demo failed - all wards must be online and connected'); }
}
function viewConflict(i) {
  const c = allConflicts()[i]; if (!c) return; const l = c.local || {}, r = c.remote, f = k => `<tr><td>${k}</td><td>${esc(l[k])}</td><td>${esc(r[k])}</td></tr>`;
  showModal(`<h3>Conflict on #${esc(c.complaint_id)} (detected at Ward ${esc(c.ward)})</h3>
  <table><thead><tr><th></th><th>Local (Ward ${esc(c.ward)})</th><th>Remote (Ward ${esc(r.last_updated_by)})</th></tr></thead><tbody>${['status', 'priority', 'description'].map(f).join('')}<tr><td>vector clock</td><td><span class="vc">${vcs(l.vclock)}</span></td><td><span class="vc">${vcs(r.vclock)}</span></td></tr><tr><td>Lamport</td><td>${l.lamport}</td><td>${r.lamport}</td></tr></tbody></table>
  <p class="muted">Neither clock is &le; the other, so the updates are <b>concurrent</b>. Resolving merges both clocks and advances Ward ${esc(c.ward)}'s entry, recording the resolution as a new update that dominates both versions.</p>
  <div class="row"><button class="btn ok" onclick="resolveConflict('${c.ward}',${c.id},'local')">Keep Local Version and Advance Clock</button><button class="btn out" onclick="resolveConflict('${c.ward}',${c.id},'remote')">Take Remote Version</button><button class="btn out" onclick="resolveConflict('${c.ward}',${c.id},'auto')">Auto (Lamport, last writer wins)</button></div>`);
}
async function resolveConflict(w, id, choice) {
  try { const r = await call(w, 'POST', '/api/resolve', {conflict_id: id, choice}); closeModal(); toast(`Resolved (${choice}) at Ward ${w}, new clock ${vcs(r.vclock)}. Synchronize to propagate.`); await poll(); }
  catch (e) { toast('Resolve failed: ' + e.message); }
}
const adm = (id, p, b) => call(id, 'POST', '/api/admin/' + p, b || {});
async function failWard(id) { await adm(id, 'fail'); toast(`Ward ${id} failed (simulated). Watch the election.`); poll(); }
async function recoverWard(id) { await adm(id, 'recover'); toast(`Ward ${id} recovered`); poll(); }
async function recoverAll() { for (const w of wardList()) if (w.reachable && w.status.down) await adm(w.id, 'recover'); toast('Recovering nodes...'); poll(); }
async function killCoordinator() { const c = coordinator(); if (!c) return toast('No coordinator yet'); await failWard(c); }
async function triggerElection() { const w = online()[0]; if (w) { await adm(w.id, 'election'); toast('Election triggered'); setTimeout(poll, 1500); } }
async function isolateWard(id) {
  for (const w of wardList()) { if (!w.reachable) continue; await adm(w.id, 'partition', {blocked: w.id === id ? S.order.filter(x => x !== id) : [id]}); }
  toast(`Ward ${id} isolated from the network`); poll();
}
async function healAll() { for (const w of wardList()) if (w.reachable) await adm(w.id, 'partition', {blocked: []}); toast('Network healed'); poll(); }
async function setAuto(v) { for (const w of wardList()) if (w.reachable) await adm(w.id, 'settings', {auto_sync: v}); toast('Auto-sync ' + (v ? 'enabled' : 'disabled')); }
async function resetAll() { if (!confirm('Delete all complaints and logs on every ward?')) return; for (const w of wardList()) if (w.reachable) await adm(w.id, 'reset'); toast('All data cleared'); poll(); }

/* ---------- boot ---------- */
window.addEventListener('hashchange', () => { const r = location.hash.slice(1); if (VIEWS[r] && r !== S.route) go(r); });
renderNav();
go(VIEWS[location.hash.slice(1)] ? location.hash.slice(1) : 'dashboard');
poll(); setInterval(poll, 3000);
