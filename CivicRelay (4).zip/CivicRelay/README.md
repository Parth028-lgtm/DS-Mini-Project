# CivicRelay - Distributed Civic Complaint Management System

Three independent ward services (FastAPI + own SQLite each) that replicate complaints, detect
conflicts with vector clocks, order events with Lamport clocks, detect failures with heartbeats
and elect a coordinator with the Bully algorithm. Runs with Docker Compose.

## Run
    docker compose up --build
Open http://localhost:8001  (Ward A = 8001, B = 8002, C = 8003).  Reset data: `docker compose down -v`

## Demo script (for screenshots / viva)
1. Complaints > create a complaint on any ward > Sync & Conflicts > Synchronize All Wards.
2. Run Conflict Demonstration > Synchronize All Wards > conflict appears (concurrent vector clocks).
3. Manual Resolve (Keep Local Version and Advance Clock) or Auto Resolve > Synchronize again > converged.
4. Election Logs > Simulate Coordinator Failure > heartbeat timeout > Bully election > new coordinator.
   Recover All Nodes > highest-priority ward takes over again.
5. Wards > Isolate (partition) a ward > Heal All Partitions.
6. Scalability: `docker compose -f docker-compose.yml -f docker-compose.scale.yml up -d --build ward-d`
   Ward D joins via Ward A, and the whole cluster picks it up automatically (Wards page).

## Syllabus mapping
Unit I architecture/design issues/middleware (3 wards, REST) | Unit II communication, fault tolerance (HTTP, heartbeats)
Unit III logical clocks, Lamport, vector clocks, election algorithms (Bully) | Unit IV containers/orchestration, scalability (Docker, Compose)

## Files
core.py (all node logic) | main.py (FastAPI routes) | static/ (dashboard) | Dockerfile | docker-compose.yml | docker-compose.scale.yml
