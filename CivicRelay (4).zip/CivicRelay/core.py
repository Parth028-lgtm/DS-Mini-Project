"""CivicRelay core: ward node logic (SQLite storage, vector clocks, Lamport clock,
replication/sync, conflict detection+resolution, heartbeats, Bully election, dynamic join)."""
import json, sqlite3, threading, time, urllib.request
from datetime import datetime, timezone


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def prio(nid):
    """Bully priority: A=1, B=2, C=3, D=4 ... (higher wins)."""
    return ord(nid[0].upper()) - 64


def public_for(nid):
    return f"http://localhost:{8000 + prio(nid)}"


# ---------------- vector clocks ----------------
def vc_norm(vc):
    return {k: int(v) for k, v in (vc or {}).items()}


def vc_leq(a, b):
    return all(a.get(k, 0) <= b.get(k, 0) for k in set(a) | set(b))


def vc_compare(a, b):
    """'equal' | 'before' (a happened before b) | 'after' | 'concurrent'"""
    a, b = vc_norm(a), vc_norm(b)
    if all(a.get(k, 0) == b.get(k, 0) for k in set(a) | set(b)):
        return "equal"
    if vc_leq(a, b):
        return "before"
    if vc_leq(b, a):
        return "after"
    return "concurrent"


def vc_merge(a, b):
    a, b = vc_norm(a), vc_norm(b)
    return {k: max(a.get(k, 0), b.get(k, 0)) for k in set(a) | set(b)}


def http_json(method, url, body=None, headers=None, timeout=3):
    data = json.dumps(body).encode() if body is not None else None
    h = {"Content-Type": "application/json"}
    h.update(headers or {})
    req = urllib.request.Request(url, data=data, method=method, headers=h)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


FIELDS = ("type", "location", "description", "status", "priority")


class Node:
    def __init__(self, node_id, db_path, peers=None, self_url=None, public_url=None,
                 http=http_json, clock=time.time, hb_timeout=6.0, spawn=None, autosync_every=15):
        self.id = node_id
        self.db_path = db_path
        self.self_url = self_url
        self.public_url = public_url or public_for(node_id)
        self.http = http
        self.clock = clock
        self.hb_timeout = hb_timeout
        self.autosync_every = autosync_every
        self.spawn = spawn or (lambda f: threading.Thread(target=f, daemon=True).start())
        self.lock = threading.RLock()
        self.peers = {}
        self.down = False
        self.blocked = set()
        self.coordinator = None
        self.last_seen = {}
        self.started = clock()
        self.last_sync = None
        self.electing = False
        self.last_election = -1e9
        self.waiting_since = None
        self.auto_sync = True
        self._last_auto = clock()
        self._init_db()
        for pid, url in (peers or {}).items():
            self.add_peer(pid, url)

    # ---------- storage ----------
    def _conn(self):
        c = sqlite3.connect(self.db_path, timeout=15)
        c.row_factory = sqlite3.Row
        return c

    def _init_db(self):
        with self._conn() as c:
            # auto-reset a database left over from an older version of the project (different schema)
            cols = [r["name"] for r in c.execute("PRAGMA table_info(complaints)")]
            if cols and "type" not in cols:
                for t in ("complaints", "conflicts", "activity", "election_log", "meta"):
                    c.execute(f"DROP TABLE IF EXISTS {t}")
            c.execute("""CREATE TABLE IF NOT EXISTS complaints(
                id TEXT PRIMARY KEY, type TEXT, location TEXT, description TEXT, ward TEXT,
                status TEXT, priority TEXT, created_at TEXT, updated_at TEXT,
                vclock TEXT, lamport INTEGER, last_updated_by TEXT)""")
            c.execute("""CREATE TABLE IF NOT EXISTS conflicts(
                id INTEGER PRIMARY KEY AUTOINCREMENT, complaint_id TEXT, remote TEXT, detected_at TEXT)""")
            c.execute("""CREATE TABLE IF NOT EXISTS activity(
                id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, ward TEXT, kind TEXT,
                complaint_id TEXT, message TEXT, vclock TEXT, lamport INTEGER)""")
            c.execute("""CREATE TABLE IF NOT EXISTS election_log(
                id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, node TEXT, event TEXT, details TEXT)""")
            c.execute("CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT)")

    def _meta_get(self, k, d="0"):
        with self._conn() as c:
            r = c.execute("SELECT v FROM meta WHERE k=?", (k,)).fetchone()
        return r["v"] if r else d

    def _meta_set(self, k, v):
        with self._conn() as c:
            c.execute("INSERT OR REPLACE INTO meta VALUES(?,?)", (k, str(v)))

    def _tick(self, other=0):
        """Lamport clock: local event -> +1 ; receive event -> max(local, remote)+1."""
        with self.lock:
            l = max(int(self._meta_get("lamport", "0")), int(other or 0)) + 1
            self._meta_set("lamport", l)
            return l

    def lamport(self):
        return int(self._meta_get("lamport", "0"))

    def _activity(self, kind, cid, msg, vc=None, lam=None):
        with self._conn() as c:
            c.execute("INSERT INTO activity(ts,ward,kind,complaint_id,message,vclock,lamport) VALUES(?,?,?,?,?,?,?)",
                      (now_iso(), self.id, kind, cid, msg, json.dumps(vc) if vc is not None else None, lam))

    def _elog(self, event, details):
        with self._conn() as c:
            c.execute("INSERT INTO election_log(ts,node,event,details) VALUES(?,?,?,?)",
                      (now_iso(), self.id, event, details))

    @staticmethod
    def _rec(row):
        d = dict(row)
        d["vclock"] = vc_norm(json.loads(d["vclock"]))
        return d

    def _save(self, r):
        with self._conn() as c:
            c.execute("INSERT OR REPLACE INTO complaints VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                      (r["id"], r["type"], r["location"], r["description"], r["ward"], r["status"],
                       r["priority"], r["created_at"], r["updated_at"], json.dumps(r["vclock"]),
                       r["lamport"], r["last_updated_by"]))

    # ---------- reads ----------
    def list_complaints(self):
        with self._conn() as c:
            return [self._rec(r) for r in c.execute("SELECT * FROM complaints ORDER BY created_at DESC, id DESC")]

    def get(self, cid):
        with self._conn() as c:
            r = c.execute("SELECT * FROM complaints WHERE id=?", (cid,)).fetchone()
        return self._rec(r) if r else None

    def list_conflicts(self):
        out = []
        with self._conn() as c:
            rows = c.execute("SELECT * FROM conflicts ORDER BY id").fetchall()
        for r in rows:
            remote = json.loads(r["remote"])
            remote["vclock"] = vc_norm(remote["vclock"])
            out.append({"id": r["id"], "complaint_id": r["complaint_id"], "local": self.get(r["complaint_id"]),
                        "remote": remote, "detected_at": r["detected_at"], "ward": self.id})
        return out

    def list_activity(self, limit=60):
        with self._conn() as c:
            rows = c.execute("SELECT * FROM activity ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["vclock"] = json.loads(d["vclock"]) if d["vclock"] else None
            out.append(d)
        return out

    def list_elog(self, limit=60):
        with self._conn() as c:
            return [dict(r) for r in c.execute("SELECT * FROM election_log ORDER BY id DESC LIMIT ?", (limit,))]

    def node_clock(self):
        vc = {}
        for r in self.list_complaints():
            vc = vc_merge(vc, r["vclock"])
        return vc

    # ---------- local writes ----------
    def create(self, ctype, location, description, priority="Medium"):
        with self.lock:
            seq = int(self._meta_get("seq", "100")) + 1
            self._meta_set("seq", seq)
            cid = f"C-{self.id}{seq}"
            vc = {self.id: 1}
            lam = self._tick()
            ts = now_iso()
            rec = {"id": cid, "type": ctype, "location": location, "description": description,
                   "ward": self.id, "status": "Open", "priority": priority, "created_at": ts,
                   "updated_at": ts, "vclock": vc, "lamport": lam, "last_updated_by": self.id}
            self._save(rec)
            self._activity("created", cid, f"New complaint {cid} created", vc, lam)
        return rec

    def update(self, cid, **changes):
        with self.lock:
            cur = self.get(cid)
            if not cur:
                return None
            for k in FIELDS:
                if changes.get(k) not in (None, ""):
                    cur[k] = changes[k]
            vc = dict(cur["vclock"])
            vc[self.id] = vc.get(self.id, 0) + 1
            cur.update(vclock=vc, lamport=self._tick(), updated_at=now_iso(), last_updated_by=self.id)
            self._save(cur)
            self._activity("updated", cid, f"Complaint {cid} updated", vc, cur["lamport"])
        return cur

    # ---------- node-to-node calls ----------
    def _call(self, method, pid, path, body=None):
        if self.down:
            raise ConnectionError("node is down")
        if pid in self.blocked:
            raise ConnectionError("network partition")
        return self.http(method, self.peers[pid]["url"] + path, body, {"X-Ward": self.id})

    def add_peer(self, pid, url, public=None):
        if pid == self.id:
            return
        self.peers[pid] = {"url": url.rstrip("/"), "public": public or public_for(pid)}
        self.last_seen.setdefault(pid, self.clock())

    def guard(self, path, from_ward=None):
        """True if this node would accept the request (used by the HTTP middleware)."""
        if not path.startswith("/api/") or path.startswith("/api/admin") or path == "/api/status":
            return True
        if self.down:
            return False
        return not (from_ward and from_ward in self.blocked)

    # ---------- replication ----------
    def import_records(self, records):
        applied = skipped = 0
        conflicts = []
        for r in records:
            r = dict(r)
            r["vclock"] = vc_norm(r["vclock"])
            local = self.get(r["id"])
            if local is None:
                self._tick(r.get("lamport"))
                self._save(r)
                applied += 1
                continue
            rel = vc_compare(r["vclock"], local["vclock"])
            if rel in ("equal", "before"):
                skipped += 1
            elif rel == "after":
                self._tick(r.get("lamport"))
                self._save(r)
                self._clear_conflicts(r["id"], r["vclock"])
                applied += 1
            elif self._add_conflict(r):
                self._tick(r.get("lamport"))
                conflicts.append(r["id"])
                self._activity("conflict", r["id"],
                               f"Conflict detected for complaint {r['id']} (concurrent updates)",
                               local["vclock"], self.lamport())
        return {"applied": applied, "skipped": skipped, "conflicts": conflicts}

    def _add_conflict(self, r):
        with self._conn() as c:
            for row in c.execute("SELECT remote FROM conflicts WHERE complaint_id=?", (r["id"],)).fetchall():
                if vc_compare(json.loads(row["remote"])["vclock"], r["vclock"]) == "equal":
                    return False
            c.execute("INSERT INTO conflicts(complaint_id, remote, detected_at) VALUES(?,?,?)",
                      (r["id"], json.dumps(r), now_iso()))
        return True

    def _clear_conflicts(self, cid, covering):
        with self._conn() as c:
            for row in c.execute("SELECT id, remote FROM conflicts WHERE complaint_id=?", (cid,)).fetchall():
                if vc_leq(vc_norm(json.loads(row["remote"])["vclock"]), covering):
                    c.execute("DELETE FROM conflicts WHERE id=?", (row["id"],))

    def sync(self):
        report = {"node": self.id, "peers": {}, "conflicts": []}
        ok = 0
        for pid in list(self.peers):
            try:
                remote = self._call("GET", pid, "/api/complaints")
                res = self.import_records(remote)
                pushed = self._call("POST", pid, "/api/import", {"records": self.list_complaints()})
                report["peers"][pid] = {"pulled": res, "pushed": pushed}
                report["conflicts"] += res["conflicts"]
                ok += 1
            except Exception as e:
                report["peers"][pid] = {"error": str(e)}
        if ok:
            self.last_sync = now_iso()
            self._activity("sync", None, f"Ward {self.id} synchronization completed ({ok} peer(s))")
        return report

    # ---------- conflict resolution ----------
    def resolve(self, conflict_id, choice="local"):
        with self._conn() as c:
            row = c.execute("SELECT * FROM conflicts WHERE id=?", (conflict_id,)).fetchone()
        if not row:
            return None
        with self.lock:
            remote = json.loads(row["remote"])
            local = self.get(row["complaint_id"])
            if choice == "auto":  # last-writer-wins on (Lamport, ward id)
                choice = "local" if (local["lamport"], prio(local["last_updated_by"])) >= \
                    (remote["lamport"], prio(remote["last_updated_by"])) else "remote"
            winner = local if choice == "local" else remote
            merged = vc_merge(local["vclock"], remote["vclock"])
            merged[self.id] = merged.get(self.id, 0) + 1  # resolution is itself a new update
            new = dict(local)
            for k in FIELDS:
                new[k] = winner[k]
            new.update(vclock=merged, lamport=self._tick(max(local["lamport"], remote["lamport"])),
                       updated_at=now_iso(), last_updated_by=self.id)
            self._save(new)
            self._clear_conflicts(new["id"], merged)
            self._activity("resolved", new["id"],
                           f"Conflict on {new['id']} resolved at Ward {self.id} (kept {choice} version)",
                           merged, new["lamport"])
        return new

    def demo_conflict(self):
        rec = self.create("Pothole", "Main Road", "Pothole near the market junction", "Medium")
        for pid in list(self.peers):
            self._call("POST", pid, "/api/import", {"records": [rec]})
        peer = next(iter(self.peers))
        self.update(rec["id"], description=f"[Ward {self.id}] Pothole is large and dangerous, urgent repair needed",
                    priority="High")
        self._call("PUT", peer, f"/api/complaints/{rec['id']}",
                   {"status": "In Progress", "description": f"[Ward {peer}] Repair crew assigned, filling in progress"})
        return {"complaint_id": rec["id"], "updated_on": [self.id, peer]}

    # ---------- membership (scalability) ----------
    def join(self, pid, url, public=None, forwarded=False):
        new = pid not in self.peers
        self.add_peer(pid, url, public)
        self.last_seen[pid] = self.clock()
        if new:
            self._activity("node", None, f"Ward {pid} joined the cluster")
        if not forwarded:
            for other in list(self.peers):
                if other != pid:
                    try:
                        self._call("POST", other, "/api/join",
                                   {"id": pid, "url": url, "public": public, "forwarded": True})
                    except Exception:
                        pass
        return {"id": self.id, "url": self.self_url, "public": self.public_url,
                "peers": [{"id": k, **v} for k, v in self.peers.items() if k != pid]}

    def bootstrap_join(self):
        for seed in list(self.peers):
            try:
                r = self._call("POST", seed, "/api/join",
                               {"id": self.id, "url": self.self_url, "public": self.public_url})
                self.add_peer(r["id"], r["url"], r["public"])
                for p in r["peers"]:
                    self.add_peer(p["id"], p["url"], p.get("public"))
                return True
            except Exception:
                continue
        return False

    # ---------- heartbeats + Bully election ----------
    def alive(self, pid):
        if pid in self.blocked or self.down or pid not in self.last_seen:
            return False
        return self.clock() - self.last_seen[pid] < self.hb_timeout

    def on_heartbeat(self, frm):
        self.last_seen[frm] = self.clock()
        return {"node": self.id, "coordinator": self.coordinator, "priority": prio(self.id)}

    def heartbeat_tick(self):
        if self.down:
            return
        t = self.clock()
        for pid in list(self.peers):
            try:
                self._call("POST", pid, "/api/heartbeat", {"from": self.id})
                self.last_seen[pid] = t
            except Exception:
                pass
        self._check_coordinator()
        if self.coordinator == self.id and self.auto_sync and t - self._last_auto >= self.autosync_every:
            self._last_auto = t
            self.sync()

    def _check_coordinator(self):
        t = self.clock()
        alive = [p for p in self.peers if self.alive(p)]
        best = max([self.id] + alive, key=prio)
        c = self.coordinator
        if c is not None and c != self.id and not self.alive(c):
            self._elog("Failure Detected", f"No heartbeat from Ward {c} (timeout)")
            self._activity("node", None, f"Ward {c} is unreachable (heartbeat timeout)")
            self.coordinator = None
            c = None
        if c is None:
            if self.waiting_since and t - self.waiting_since < self.hb_timeout:
                return
            self.waiting_since = None
            self.start_election()
        elif (best == self.id and c != self.id) or (c == self.id and best != self.id):
            self.start_election()

    def start_election(self, force=False):
        if self.down:
            return
        with self.lock:
            t = self.clock()
            if self.electing or (not force and t - self.last_election < self.hb_timeout / 2):
                return
            self.electing = True
            self.last_election = t
        try:
            self._elog("Election Message", f"Ward {self.id} initiates election (priority {prio(self.id)})")
            answered = False
            for pid in sorted(self.peers, key=prio):
                if prio(pid) > prio(self.id):
                    try:
                        r = self._call("POST", pid, "/api/election", {"from": self.id})
                        if r.get("ok"):
                            answered = True
                            self._elog("Election Response", f"Ward {pid} responds (priority {prio(pid)})")
                    except Exception:
                        pass
            if answered:
                self.waiting_since = t
                if self.coordinator == self.id:
                    self.coordinator = None
            else:
                self._become_coordinator()
        finally:
            self.electing = False

    def on_election(self, frm):
        self.last_seen[frm] = self.clock()
        self._elog("Priority Check", f"Ward {self.id} has higher priority than Ward {frm}")
        self.spawn(lambda: self.start_election(force=True))
        return {"ok": True, "node": self.id, "priority": prio(self.id)}

    def _become_coordinator(self):
        self.coordinator = self.id
        self.waiting_since = None
        self._elog("Coordinator Elected", f"Ward {self.id} is now the coordinator")
        self._activity("election", None, f"Coordinator changed to Ward {self.id}")
        for pid in list(self.peers):
            try:
                r = self._call("POST", pid, "/api/coordinator", {"id": self.id})
                if r.get("ok"):
                    self._elog("Acknowledgement", f"Ward {pid} acknowledges new coordinator")
            except Exception:
                pass
        self._elog("Election Complete", f"System is running with Ward {self.id} as coordinator")

    def on_coordinator(self, cid):
        if cid != self.id and prio(cid) < prio(self.id) and not self.down:
            self.spawn(lambda: self.start_election(force=True))  # a lower node cannot rule over me
            return {"ok": False}
        self.last_seen[cid] = self.clock()
        if self.coordinator != cid:
            self._activity("election", None, f"Coordinator changed to Ward {cid}")
        self.coordinator = cid
        self.waiting_since = None
        return {"ok": True}

    # ---------- failure / partition simulation ----------
    def set_down(self, down):
        if down and not self.down:
            self.down = True
            self.coordinator = None
            self._elog("Node Failure", f"Ward {self.id} went offline (simulated failure)")
            self._activity("node", None, f"Ward {self.id} node went offline")
        elif not down and self.down:
            self.down = False
            self.coordinator = None
            for pid in self.peers:
                self.last_seen[pid] = self.clock()
            self._elog("Node Recovery", f"Ward {self.id} is back online and starts an election")
            self._activity("node", None, f"Ward {self.id} is back online")
            self.spawn(lambda: self.start_election(force=True))

    def set_blocked(self, ids):
        self.blocked = {i for i in ids if i != self.id}
        self._activity("node", None, f"Ward {self.id} network partition: {sorted(self.blocked) or 'healed'}")

    def reset(self):
        with self._conn() as c:
            for t in ("complaints", "conflicts", "activity", "election_log", "meta"):
                c.execute(f"DELETE FROM {t}")
        self.coordinator = None
        self.last_sync = None

    def status(self):
        t = self.clock()
        return {
            "node": self.id, "priority": prio(self.id), "down": self.down, "blocked": sorted(self.blocked),
            "coordinator": self.coordinator, "lamport": self.lamport(), "vclock": self.node_clock(),
            "uptime": round(t - self.started), "last_sync": self.last_sync, "public": self.public_url,
            "complaints": len(self.list_complaints()), "conflicts": len(self.list_conflicts()),
            "auto_sync": self.auto_sync,
            "peers": {pid: {"public": p["public"], "priority": prio(pid), "alive": self.alive(pid),
                            "last_seen_ago": round(t - self.last_seen[pid], 1) if pid in self.last_seen else None}
                      for pid, p in self.peers.items()},
        }
